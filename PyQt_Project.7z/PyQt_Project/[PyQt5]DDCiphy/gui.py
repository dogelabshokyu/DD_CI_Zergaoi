import sys
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QAction, qApp, QDesktopWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import  QTime, Qt

class DCBA(QMainWindow):
    def __init__(self):
        super().__init__()

        self.time = QTime.currentTime()
        self.initUI()

    # 초기화 담당 함수
    def initUI(self):

        exitAction = QAction(QIcon('exit.png'), '종료하기', self)
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('프로그램 종료')
        exitAction.triggered.connect(qApp.quit)

        #self.statusBar().showMessage('develop by DDC_Semicolon_Network/Security Team')
        self.statusBar().showMessage(self.time.toString('hh:mm:ss'))

        menubar = self.menuBar()
        menubar.setNativeMenuBar(False)
        fileMenu = menubar.addMenu('파일')
        fileMenu.addAction(exitAction)

        self.toolbar = self.addToolBar('종료')
        self.toolbar.addAction(exitAction)

        #Label
        # label1 = QLabel('Label1', self)
        # label1.move(20, 20)
        # label2 = QLabel('Label2', self)
        # label2.move(20, 60)


        #button
        # btn1 = QPushButton('Button1', self)
        # btn1.move(80,13)
        # btn2 = QPushButton('Button2', self)
        # btn2.move(80, 53)
        okButton = QPushButton('OK')
        cancelButton = QPushButton('Cancel')

        #place
        hbox = QHBoxLayout()
        hbox.addStretch(1)
        hbox.addWidget(okButton)
        hbox.addWidget(cancelButton)
        hbox.addStretch(1)

        vbox = QVBoxLayout()
        vbox.addStretch(3)
        vbox.addLayout(hbox)
        vbox.addStretch(1)

        self.setLayout(vbox)
        self.setWindowTitle('귀여운 암호상자')
        self.setWindowIcon(QIcon('DCBA_icon.png'))
        self.resize(300,500)
        self.show()

    # 화면 중앙배치 함수
    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = DCBA()
    sys.exit(app.exec_())
